﻿using System;
using System.Collections.Generic;

namespace ExamM.middledb;

public partial class Middle
{
    public DateTime Date { get; set; }

    public int Price { get; set; }

    public int State { get; set; }
}
